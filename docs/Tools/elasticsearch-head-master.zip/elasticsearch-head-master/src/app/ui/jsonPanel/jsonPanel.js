(function( app ) {

    var ui = app.ns("ui");

    ui.JsonPanel = ui.InfoPanel.extend({
        defaults: {
            json: null, // (required)
            modal: false,
            open: true,
            autoRemove: true,
            height: 500,
            width: 600
        },

        _baseCls: "uiPanel uiInfoPanel uiJsonPanel",

        _body_template: function() {
            var body = this._super();
            body.children=[
                { tag: "input", type: "checkbox", cls: "uiJsonPanelMode", onchange: this._change_mode.bind(this)},
                " Edit",
                new ui.JsonEditor({ obj: this.config.json }),
                new ui.JsonPretty({ obj: this.config.json })

            ];
            this.edit=$(body).find(".uiJsonEditor");
            this.displayPanel=$(body).find(".uiJsonPretty");
            this.edit.hide();
            return body;
        } ,
        _change_mode:function() {
            this.edit.toggle();
            this.displayPanel.toggle();
        }
    });
})( this.app );
