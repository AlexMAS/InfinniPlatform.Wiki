(function( app ) {

    var ui = app.ns("ui");

    ui.RetrieveColumnPanel = ui.InfoPanel.extend({
        defaults: {
            json: null, // (required)
            modal: false,
            open: true,
            autoRemove: true,
            height: 500,
            width: 600
        },

        _baseCls: "uiPanel uiInfoPanel uiJsonPanel",

        init: function() {
            this._super();
            var $body=$(this).find(".uiPanel-body");
            var deletedColumns = JSON.parse(localStorage["deletedColumns"]);
            if(deletedColumns.length){
                var columns=$("<div/>",{ style : "height: 450px; overflow-y: scroll;"});
                $.each(deletedColumns, function(name, data) {
                    columns.append({tag:"DIV", children:[{ tag: "INPUT", type: "CHECKBOX", id: "RetrieveColumn-"+name},{ tag: "LABEL", text: data, for: "RetrieveColumn-"+name}]});
                });
                $body.append(
                    columns,
                    { tag: "Button", text: "Вернуть", style: "float:right", onClick:  this._retrieveColumn.bind(this)},
                    { tag: "Button", text: "Вернуть всё", style: "float:right", onClick:  this._retrieveAllColumn.bind(this)}
                );
            }else{
                $body.append("В данный момент отображаются все поля.");
            }
        },

        _retrieveColumn: function(){
            var retrieve=$(this).find("input:checkbox:checked")
                                .siblings("label")
                                .map(function(el){return this.innerHTML;});
            var deletedColumns=JSON.parse(localStorage["deletedColumns"]);
            deletedColumns=jQuery.grep(deletedColumns, function(val){
                return (jQuery.inArray(val,retrieve)===-1);
            });
            localStorage["deletedColumns"]=JSON.stringify(deletedColumns);
            app.globalVar.query.query();
            $(this).closest(".uiPanel")
                   .find(".uiPanel-close")
                   .click();
        },

        _retrieveAllColumn: function(){
            localStorage["deletedColumns"]=JSON.stringify(new Array());
            app.globalVar.query.query();
            $(this).closest(".uiPanel")
                .find(".uiPanel-close")
                .click();
        }
    })
})( this.app );

