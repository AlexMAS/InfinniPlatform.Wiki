(function( app ) {

    var ui = app.ns("ui");

    ui.TypeMenu = ui.AbstractWidget.extend({
        defaults: {
            typeName: null
        },

        init: function() {
            this._super();
            this.typeName = this.config.typeName;
            this.el = $(this._main_template());
            $(document).click(function(){
                $(".uiQueryFilter-types-menu").remove();
            });
            $(document).on("contextmenu",function(){
                $(".uiQueryFilter-types-menu").remove();
            });
            $(document).on("scroll",function(){
                $(".uiQueryFilter-types-menu").remove();
            });
        },

        _main_template: function() {
            var base_uri=localStorage["base_uri"];

            var selectedIndices = this._get_selected_indices();
            var type=this.typeName;

            return { tag: "DIV", cls: "uiQueryFilter-types-menu", child: [
                { tag: "DIV", cls: "item", text: "Удалить", onclick: function(jEv) {
                    jEv.stopPropagation();
                    $(".uiQueryFilter-types-menu").remove();

                    var message;

                    if(selectedIndices.length==0){
                        message = "Вы уверены, что хотите удалить тип " + type + " во всех индексах ?";
                        selectedIndices=['_all'];
                    }
                    else{
                        message = "Вы уверены, что хотите удалить тип " + type + " в индексах " + selectedIndices.join(',') + " ?";
                    }

                    if (confirm(message)) {
                        selectedIndices.forEach( function(index){
                                $.ajax({
                                    url: base_uri+index+"/_mapping/"+type+"/",
                                    type: "DELETE",
                                    dataType: "json",
                                    error: function(xhr, type, message) {
                                        if("console" in window) {
                                            console.log({ "XHR Error": type, "message": message });
                                        }
                                        alert("Не удается удалить тип в индексе " + index + ".");
                                    },
                                    success: function() {
                                        $(".uiApp-headerMenuItem:contains('Browser')").click();
                                        alert("Тип успешно удален");
                                    }
                                });
                            }
                        );
                    }
                }}
            ] };
        },

        _get_selected_indices: function(){
            var selectedIndices = $('.uiQueryFilter-index.selected');
            var indexList = new Array();

            selectedIndices.each(  function(){
                indexList.push( $(this).html() );
            } );

            return indexList;
        }

    });
})( this.app );


