﻿namespace Reflexil.Editors
{
    partial class AssemblyNameDefinitionAttributesControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ((System.ComponentModel.ISupportInitialize)(this.Revision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Build)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Major)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).BeginInit();
            this.SplitContainer.Panel2.SuspendLayout();
            this.SplitContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // LabHash
            // 
            this.LabHash.Location = new System.Drawing.Point(11, 169);
            this.LabHash.Visible = false;
            // 
            // Hash
            // 
            this.Hash.Location = new System.Drawing.Point(102, 166);
            this.Hash.Visible = false;
            // 
            // SplitContainer
            // 
            // 
            // AssemblyDefinitionAttributesControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.Name = "AssemblyDefinitionAttributesControl";
            ((System.ComponentModel.ISupportInitialize)(this.Revision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Build)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Major)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).EndInit();
            this.SplitContainer.Panel2.ResumeLayout(false);
            this.SplitContainer.Panel2.PerformLayout();
            this.SplitContainer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
    }
}
