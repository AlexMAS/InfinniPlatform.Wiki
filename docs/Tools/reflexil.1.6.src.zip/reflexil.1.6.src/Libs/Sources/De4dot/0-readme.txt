De4dot source code is here. It's not directly used by the solution.

As De4dot is using a custom Mono.Cecil version, we have to update namespaces and ilmerge all.
So it can be used without any conflicts.