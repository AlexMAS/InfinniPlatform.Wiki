using NUnit.Core.Extensibility;

namespace DeMono.Cecil.Tests {

	[NUnitAddin]
	public class CecilMdbAddin : CecilTestAddin {
	}
}
