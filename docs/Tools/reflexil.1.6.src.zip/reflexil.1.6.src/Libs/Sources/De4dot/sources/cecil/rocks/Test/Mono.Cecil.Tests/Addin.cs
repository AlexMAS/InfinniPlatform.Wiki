using NUnit.Core.Extensibility;

namespace DeMono.Cecil.Tests {

	[NUnitAddin]
	public class CecilRocksAddin : CecilTestAddin {
	}
}
