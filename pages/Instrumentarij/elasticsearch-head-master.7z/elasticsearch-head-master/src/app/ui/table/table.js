( function( $, app ) {

	var ui = app.ns("ui");

	ui.Table = ui.AbstractWidget.extend({
		defaults: {
			store: null, // (required) implements interface app.data.DataSourceInterface
			height: 0,
			width: 0
		},
		_baseCls: "uiTable",
		init: function(parent) {
			this._super();
			this.initElements(parent);
            this.deletedColumns = new Array();
            if( localStorage["deletedColumns"] !== undefined ) {
                this.deletedColumns = JSON.parse(localStorage["deletedColumns"]);
            }
            localStorage["deletedColumns"] = JSON.stringify(this.deletedColumns);
			this.config.store.on("data", this._data_handler);
		},
		attach: function(parent) {
			if(parent) {
				this._super(parent);
				this._reflow();
			}
		},
		initElements: function(parent) {
			this.el = $(this._main_template());
			this.body = this.el.find(".uiTable-body");
			this.headers = this.el.find(".uiTable-headers");
			this.tools = this.el.find(".uiTable-tools");
            this.index = null;
            this.id = null;
            this.attach( parent );
		},
		_data_handler: function(store) {
			this.tools.text(store.summary);
            var deleted=JSON.parse(localStorage["deletedColumns"]);
            columns = jQuery.grep(store.columns, function(val){
                return (jQuery.inArray(val,deleted)===-1);
            });
			this.headers.empty().append(this._header_template(columns));
			this.body.empty().append(this._body_template(store.data, columns));
			this._reflow();
            var selected_row = $(this).find('.uiTable-row:contains("'+this.selected_row+'")')[0];
            if(selected_row == null) $(this).find(".uiTable-row").first().addClass("selected");
            else $(selected_row).addClass("selected");
		},
		_reflow: function() {
			var firstCol = this.body.find("TR:first TH.uiTable-header-cell > DIV"),
					headers = this.headers.find("TR:first TH.uiTable-header-cell > DIV");
			for(var i = 0; i < headers.length; i++) {
				$(headers[i]).width( $(firstCol[i]).width() );
			}
			//this._scroll_handler();
		},
//		_scroll_handler: function(jEv) {
//			this.el.find(".uiTable-headers").scrollLeft(this.body.scrollLeft());
//		},
		_dataClick_handler: function(jEv) {
			var row = $(jEv.target).closest("TR");
			if(row.length) {
				this.fire("rowClick", this, { row: row } );
			}
		},
		_headerClick_handler: function(jEv) {
			var header = $(jEv.target).closest("TH.uiTable-header-cell");
			if(header.length) {
				this.fire("headerClick", this, { header: header, column: header.data("column"), dir: header.data("dir") });
			}
		},
		_main_template: function() {
			return { tag: "DIV", id: this.id(), css: { width: this.config.width + "px" }, cls: this._baseCls, children: [
                { tag: "DIV", cls: "uiTable-filter",
                    children: [
                        { tag: "INPUT", type: "text", cls: "SearchPrefix", placeholder: "Prefix"},
                        { tag: "INPUT", type: "text", cls: "SearchField", placeholder: "Field"},
                        { tag: "INPUT", type: "text", cls: "SearchValue", placeholder: "Value" },
                        { tag: "BUTTON", type: "button", text: "Search", onclick: this._search_by_value},
                        { tag: "BUTTON", type: "button", text: "Clear Filter", onclick: this._clear_filter}
                    ],
                    onKeyup: function(event){if(event.keyCode === 13){this._search_by_value();}}.bind(this)},
				{ tag: "DIV", cls: "uiTable-tools" },
                { tag: "DIV", child:[
                    { tag: "P", class: "retrieveColumn", text:"Вернуть поля", onClick: this._retrieveColumn.bind(this)}
                ]},
				{ tag: "DIV", cls: "uiTable-headers",
					onClick: this._headerClick_handler
				},
				{ tag: "DIV", cls: "uiTable-body",
					onClick: this._dataClick_handler,
					onScroll: this._scroll_handler,
					css: { height: this.config.height + "px", width: this.config.width + "px" }
				}
			] };
		},
        _retrieveColumn: function(){
            $('body').append(new ui.RetrieveColumnPanel());
        },
        _search_by_value: function(){
            var query= app.globalVar.query;
            var prefix=$(".SearchPrefix",this.filter)[0].value;
            var fieldName=$(".SearchField",this.filter)[0].value;
            var value=$(".SearchValue",this.filter)[0].value.toLowerCase();
            var filter=new Object();

            if(prefix != ""){
                if(prefix[prefix.length-1] != ".") prefix=prefix+".";
                fieldName=prefix+fieldName;
            }
            //console.log(fieldName);
            filter[fieldName]=value;

            if(fieldName === "") query.clearFilter();
            else query.addFilter(filter);

            query.query();
        },
        _clear_filter: function(){
            var query= app.globalVar.query;
            $(".SearchField",this.filter).val("");
            $(".SearchValue",this.filter).val("");
            query.clearFilter();
            query.query();
        },
		_header_template: function(columns) {
			var ret = { tag: "TABLE", child: this._headerRow_template(columns) };
            ret.child.children.unshift(this._headerFirstCap_template());
			ret.child.children.push(this._headerEndCap_template());
			return ret;
		},
		_headerRow_template: function(columns) {
			return { tag: "TR", cls: "uiTable-header-row", children: columns.map(function(column) {
				var dir = ((this.config.store.sort.column === column) && this.config.store.sort.dir) || "none";
				return { tag: "TH", data: { column: column, dir: dir }, cls: "uiTable-header-cell" + ((dir !== "none") ? " uiTable-sort" : ""), children: [
					{ tag: "DIV", children: [
                        { tag: "P", text:"x", onClick: this._deleteColumn.bind(this)},
						{ tag: "DIV", cls: "uiTable-headercell-menu", text: dir === "asc" ? "\u25b2" : "\u25bc" },
                        { tag: "DIV", cls: "uiTable-headercell-text", text: column }
					]}
				]};
			}, this)};
		},
        _deleteColumn: function(ev){
            ev.stopPropagation();
            var columnName = $(ev.target).siblings(".uiTable-headercell-text")[0].innerHTML;
            this.deletedColumns.push(columnName);
            this.deletedColumns.sort()
                               .reverse();
            localStorage["deletedColumns"] = JSON.stringify($.unique(this.deletedColumns));
            app.globalVar.query.query();
        },
        _headerFirstCap_template: function() {
            return { tag: "TH", cls: "uiTable-header-cell", child: { tag: "DIV" } };
        },
		_headerEndCap_template: function() {
			return { tag: "TH", cls: "uiTable-headerEndCap", child: { tag: "DIV" } };
		},
		_body_template: function(data, columns) {
			return { tag: "TABLE", children: []
				.concat(this._headerRow_template(columns))
				.concat(data.map(function(row) {
					return { tag: "TR", data: { row: row }, cls: "uiTable-row",
                        children: [
                            { tag: "TD", child:
                                { tag: "BUTTON", type: "button", text: "Display", onclick: function(event){
                                    var row=$(this).parent().parent();
                                    event.stopPropagation();
                                    $(this).find(".uiTable-editor-data").text(JSON.stringify(row.data("row")._source, null, 2));
                                    this.preview = new app.ui.JsonPanel({
                                        title: i18n.text("Browser.ResultSourcePanelTitle"),
                                        json: row.data("row")._source
                                    });
                                }}
                            },
                            columns.map(function(column){
                            return { tag: "TD", cls: "uiTable-cell", child: { tag: "DIV", text: (row[column] || "").toString() } };
                            })

                        ]};
				}))
			};
		}

	});

})( this.jQuery, this.app );
