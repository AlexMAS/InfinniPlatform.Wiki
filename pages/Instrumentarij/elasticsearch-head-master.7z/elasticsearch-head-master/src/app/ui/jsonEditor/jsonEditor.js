(function( app ) {

    var ui = app.ns("ui");

    ui.JsonEditor = ui.AbstractWidget.extend({
        defaults: {
            configInfo: null,
            sourceInfo: null
        },

        init: function() {
            this._super();
            if(this.config.obj!=null) this.sourceInfo=JSON.parse(JSON.stringify(this.config.obj._source));
            this.configInfo=JSON.parse(JSON.stringify(this.config.obj));
            delete this.configInfo._source;
            this.el = $(this._main_template());
        },

        _main_template: function() {
            return { tag: "div", cls: "uiJsonEditor", child:[
                { tag: "PRE", text: JSON.stringify(this.configInfo, null, " ").replace("}",' "_source":')},
                { tag: "TEXTAREA", cls: "uiJsonEditorSourceInfo", text: JSON.stringify(this.sourceInfo, null, " ")},
                { tag: "PRE", text: "}"},
                { tag: "BUTTON", type: "button", text: "Apply", onclick: this._update_items.bind(this) },
                { tag: "BUTTON", type: "button", text: "Delete", onclick: this._delete_items.bind(this) }
            ]};
        },

        _update_items: function() {
            var base_uri=localStorage["base_uri"];
            var index=this.configInfo._index;
            var type= this.configInfo._type;
            var id= this.configInfo._id;
            var source=$(this).find(".uiJsonEditorSourceInfo")[0].value;
            var jsonPanel=$(this).parent();
            $.ajax({
                url: base_uri+index+"/"+type+"/"+id+"/",
                type: "PUT",
                dataType: "json",
                data: source,
                error: function(xhr, type, message) {
                    if("console" in window) {
                        console.log({ "XHR Error": type, "message": message });
                    }
                    alert("Изменить значение не удалось.");
                },
                success: function() {
                    setTimeout( function() { app.globalVar.query.query(); }, 1000);
                    jsonPanel.siblings(".uiPanel-titleBar").find(".uiPanel-close").click();
                }
            });
        },

        _delete_items: function() {
            var base_uri=localStorage["base_uri"];
            var index=this.configInfo._index;
            var type= this.configInfo._type;
            var id= this.configInfo._id;
            var jsonPanel=$(this).parent();

            $.ajax({
                url: base_uri+index+"/"+type+"/"+id+"/",
                type: "DELETE",
                dataType: "json",
                error: function(xhr, type, message) {
                    if("console" in window) {
                        console.log({ "XHR Error": type, "message": message });
                    }
                    alert("Не удается удалить запись. Проверьте, возможно она уже удалена.");
                },
                success: function() {
                    jsonPanel.text("Запись удалена");
                    setTimeout( function() { app.globalVar.query.query(); }, 1000);//будем надеяться, что ui.Browser уже создан и app.globalVar.query инициализированно
                }
            });
        }
    });
})( this.app );

