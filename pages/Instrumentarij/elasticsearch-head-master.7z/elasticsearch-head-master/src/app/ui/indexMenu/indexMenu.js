(function( app ) {

    var ui = app.ns("ui");

    ui.IndexMenu = ui.AbstractWidget.extend({
        defaults: {
            indexName: null
        },

        //_baseCls: "uiQueryFilter-indices-menu",

        init: function() {
            this._super();
            this.indexName = this.config.indexName;
            this.el = $(this._main_template());
            $(document).click(function(){
                $(".uiQueryFilter-indices-menu").remove();
            });
            $(document).on("contextmenu",function(){
                $(".uiQueryFilter-indices-menu").remove();
            });
            $(document).on("scroll",function(){
                $(".uiQueryFilter-indices-menu").remove();
            });
        },

        _main_template: function() {
            var base_uri=localStorage["base_uri"];
            var index=this.indexName;
            return { tag: "DIV", cls: "uiQueryFilter-indices-menu", child: [
                { tag: "DIV", cls: "item", text: "Удалить", onclick: function(jEv) {
                    jEv.stopPropagation();
                    $(".uiQueryFilter-indices-menu").remove();

                    if (confirm("Вы уверены, что хотите удалить индекс " + base_uri + index + "/" + " ?")) {
                        $.ajax({
                                    url: base_uri+index+"/",
                                    type: "DELETE",
                                    dataType: "json",
                                    error: function(xhr, type, message) {
                                        if("console" in window) {
                                            console.log({ "XHR Error": type, "message": message });
                                        }
                                        alert("Не удается удалить индекс.");
                                    },
                                    success: function() {
                                        $(".uiApp-headerMenuItem:contains('Browser')").click();
                                    }
                                });
                    }
                }}
            ] };
        }

    });
})( this.app );


